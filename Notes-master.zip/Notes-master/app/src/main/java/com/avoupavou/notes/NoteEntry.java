package com.avoupavou.notes;

import java.util.ArrayList;

/**
 * Created by zsy 2019.
 */
public class NoteEntry {
    public static ArrayList<NoteEntry> notesList;


    public static final int PLAIN_TEXT =1;

    private String title;
    private String text;
    private int type;
    private int id;


    public NoteEntry() {
        this.id =-1;
        type =0;
        title = "New Note";
        text = "";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}

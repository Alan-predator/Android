package com.avoupavou.notes;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends Activity {

    private Timer timer;
    private int countDown = 5;
    private TextView tvCountdown;
    private Handler handler = new Handler();
   private Handler mMainHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.setClass(getApplication(), SplashActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            // overridePendingTransition must be called AFTER finish() or startActivity, or it won't work.
            //overridePendingTransition(R.anim.activity_in, R.anim.splash_out);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_pic);


        tvCountdown = findViewById(R.id.tv_countdown);
        timer = new Timer();
        //启动定时器， 延迟0妙启动，之后每隔1妙执行一次TimerTask
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                //定时器里更新UI
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        //如果时间到了，打开Activity
                        if (countDown < 0){
                            startMainActivity();
                            return;
                        }
                        tvCountdown.setText(countDown+"s");
                        countDown--;
                    }
                });
            }
        }, 1000, 1000);

        //添加点击事件监听，点了后直接打开Activity
        tvCountdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMainActivity();
            }
        });

//        这么写会卡住屏幕3妙
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                Intent intent = new Intent(SplashActivity.this,MainActivity.class);
//                startActivity(intent);
//                finish();
//            }
//        }, 3000);
    }


    //启动MainActivity
    private void startMainActivity(){
//        写法太麻烦
//        Intent intent = new Intent(Intent.ACTION_MAIN);
//        intent.setClass(getApplication(), SplashActivity.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
        //打开Activity前结束定时器
        timer.cancel();
        //打开 Activity
        startActivity(new Intent(this, MainActivity.class));
    }
}
package com.avoupavou.notes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link NoteListFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link NoteListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NoteListFragment extends Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private ArrayList<NoteEntry> notesList;


    NotesListAdapter notesListAdapter;

    private RecyclerView notesRecyclerView;
    private LinearLayoutManager notesLayoutManager;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public NoteListFragment() {
        // Required empty public constructor
        notesList = NoteEntry.notesList;
        notesListAdapter = new NotesListAdapter(notesList,this);

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NoteListFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static NoteListFragment newInstance(String param1, String param2) {
        NoteListFragment fragment = new NoteListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        readEntriesFromDB();
    }


    private void readEntriesFromDB(){
        NoteReaderHelper mDbHelper = new NoteReaderHelper(getContext());
        SQLiteDatabase db = mDbHelper.getReadableDatabase();

        // Define a projection that specifies which columns from the database
        // you will actually use after this query.
        String[] projection = {
                NoteContract.NoteEntryDb._ID,
                NoteContract.NoteEntryDb.COLUMN_NAME_TITLE,
                NoteContract.NoteEntryDb.COLUMN_NAME_BODY
        };



        // How you want the results sorted in the resulting Cursor
        String sortOrder =
                NoteContract.NoteEntryDb._ID + " ASC";

        Cursor cursor = db.query(
                NoteContract.NoteEntryDb.TABLE_NAME,        // The table to query
                projection,                                 // The columns to return
                null,                                       // The columns for the WHERE clause
                null,                                       // The values for the WHERE clause
                null,                                       // don't group the rows
                null,                                       // don't filter by row groups
                sortOrder                                   // The sort order
        );

        //notesList = new ArrayList<>();
        while(cursor.moveToNext()) {
            NoteEntry entry = new NoteEntry();
            Log.d("ListFragment",cursor.getString(cursor.getColumnIndexOrThrow(NoteContract.NoteEntryDb._ID)));
            entry.setTitle(cursor.getString(
                    cursor.getColumnIndexOrThrow(NoteContract.NoteEntryDb.COLUMN_NAME_TITLE)));
            entry.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(NoteContract.NoteEntryDb.COLUMN_NAME_BODY)));
            entry.setId((int) cursor.getLong(
                    cursor.getColumnIndexOrThrow(NoteContract.NoteEntryDb._ID)));
            notesList.add(entry);
        }
        notesListAdapter.notifyDataSetChanged();
        cursor.close();
        mDbHelper.close();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View inf = inflater.inflate(R.layout.fragment_note_list, container, false);

        notesRecyclerView = (RecyclerView) inf.findViewById(R.id.notes_recycler_view);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        notesRecyclerView.setHasFixedSize(true);

        // use a linear layout manager
        notesLayoutManager= new LinearLayoutManager(this.getContext());
        notesRecyclerView.setLayoutManager(notesLayoutManager);


        // specify an adapter (see also next example)

        notesRecyclerView.setAdapter(notesListAdapter);
        return inf;
    }


    public void onAddNotePressed() {
        NoteEntry entry = new NoteEntry();


        NoteReaderHelper mDbHelper = new NoteReaderHelper(getContext());
        // Gets the data repository in write mode
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NoteContract.NoteEntryDb.COLUMN_NAME_TITLE, entry.getTitle());
        values.put(NoteContract.NoteEntryDb.COLUMN_NAME_BODY, "");

        int rowID  = (int) db.insert(NoteContract.NoteEntryDb.TABLE_NAME, null, values);
        entry.setId(rowID);
        Log.d("SingleFrag","New row added with id= " + rowID);

        notesList.add(entry);
        notesListAdapter.notifyItemInserted(notesList.size()-1);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        int itemPosition = notesRecyclerView.getChildLayoutPosition(v);
        mListener.onFragmentInteraction(itemPosition);
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(int pos);
    }

}

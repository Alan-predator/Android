# Notes
Simple note app for android

## Decription
The app offers basic functionalities found on note apps. The main purpose of this project is to get familiar with Android sdk.

## Features
* Create a note with title and body and save it to sqlite database localy on exit.
* Edit a note and save edits on exit.
* Change each note's color.
* Select multiple notes and delete them.
